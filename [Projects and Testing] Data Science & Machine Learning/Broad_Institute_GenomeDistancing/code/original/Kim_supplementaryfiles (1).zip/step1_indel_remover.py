import os
import subprocess
import re

# takes *vcf files from Pilon and removes indels and duplicates
# output is two files; *_head.vcf (header) and *_snp.vcf (indel_removed vcf file)


# set filepath of *.vcf fi;es
filepath = '/vcfdir/'

# get all the files
listfiles = os.listdir(filepath)

# filter the file list for "*.vcf"
R = re.compile('.*vcf')
listfilesR=filter(R.match,listfiles)

listfilesR.sort()
# pairs up R1 and R2 file names
#R1R2list = zip(listfilesR[0::2])

# loop through all pairs and execute commands
# for loop requires colon, tab each line inside
for R1R2 in listfilesR:
    # cycle Rname
    Rname = R1R2
    
    # get string before first underscore (filetag = ex. 1A, 1B, 1C)
    filetag = Rname.split('.')[0]
	# define filename - filepath + Rname
    filename = filepath + Rname
    
	# set cmd_to_run
    cmd_to_run = ['head', '-31', filename]

    print cmd_to_run
    # run header save
    subprocess.call(cmd_to_run,stdout=open(filetag + '_head.vcf', 'w'))

    # define checkDP.awk directory
    # switch cmd_to_run to indel deletion prog (checkDP.awk)
    cmd_to_run = ['gawk', '-f', '/dir/checkDP.awk', filename]
    
    print cmd_to_run
    # run checkDP.awk
    subprocess.call(cmd_to_run,stdout=open(filetag + '_snp.vcf', 'w'))
