% Finds bases in the reference genome that has sufficient coverage and
% mapping quality for analaysis and masks the rest
% requires: 1) *.mat file parsed from Pilon vcf with 'vcftomatrix_vcf_v7.py'
%           2) reference genome fasta file converted to *.mat file (A=1, C=2, G=4, T=8)
% Outputs *.mat file with:
% 1) mapped bases of sufficient quality (defined by user)
% 2) positive snp vs the reference genome
% 3) negative snps = bases that are the same to the reference genome

clear all
load('3_AT_only.mat'); 

%filter parameters
filter = [4 5 6];

DPfilter = 6;
MQfilter = 45;
dataPAC = uint16(data);
clear data;

%Make mask (data row size), (data column size)
mask = ones(size(dataPAC,1),size(dataPAC,2));

%Mask out the filtered values
for iFilter = 1:length(filter)
mask(dataPAC(:,:,5)==filter(iFilter))=0;
end

% mask all 2 page data in data that is less than the DP and MQ and AF filter threshold
mask(dataPAC(:,:,2)<DPfilter)=0;
mask(dataPAC(:,:,3)<MQfilter)=0;
mask(dataPAC(:,:,1)~=1 & dataPAC(:,:,1)~=2 & dataPAC(:,:,1)~=4 & dataPAC(:,:,1)~=8)=0;
%mask(dataPAC(:,:,4)<AFfilter & dataPAC(:,:,4)>1)=0; %%need to get rid of
%%this because SNP_pos at AF<210 will all be masked while sample_snp is detected at a lower AF threshold 

%change mask to uint8 for compatibility
mask = uint16(mask);
maskPAC = mask;

load('PAv14_ref_seq.mat') % reference genome mat file
datas3 = dataPAC(:,:,1).*maskPAC;
datas3(:,:,2) = dataPAC(:,:,2);
datas3(:,:,3) = dataPAC(:,:,3);
datas3(:,:,4) = dataPAC(:,:,4);
datas3(:,:,5) = dataPAC(:,:,5);
datas3(2,:,1) = PAv14_ref_seq;
pos_snp_ind = (datas3(1,:,1)~=PAv14_ref_seq) & (datas3(1,:,2)>0) & (datas3(1,:,1)>0) & ((datas3(1,:,1)<9)); 
pos = find(pos_snp_ind);
snp = find(datas3(1,pos,1) ~= datas3(2,pos,1));
pos_snp = pos; % SNPs vs reference base
truebase = datas3(1,:,1); % sample bases

datas3 = dataPAC(:,:,1).*maskPAC;
datas3(:,:,2) = dataPAC(:,:,2);
datas3(:,:,3) = dataPAC(:,:,3);
datas3(:,:,4) = dataPAC(:,:,4);
datas3(:,:,5) = dataPAC(:,:,5);
mappedidx_truth = find((datas3(1,:,2)~=0) & ((datas3(1,:,1))~=0)); %index of all mapped positions (base and coverage exists)
PAv14_ref_seq_mapped_truth=PAv14_ref_seq(mappedidx_truth); %mask all unmapped pos of ref genome
conc = sum(maskPAC(:,mappedidx_truth)); %sum all rows of masks only in the mapped positions in the genome
concord = find(conc); %positions that have not been masked in the mapped regions of the genome
unmasked=length(concord);
mappedlenght = length(conc)
sensitivity = length(concord)/length(conc);

neg_snp = setdiff(mappedidx_truth,pos_snp); % bases that are the same to the reference genome

save('truebase150727_124cov.mat','truebase','pos_snp','pos_snp_ind','PAv14_ref_seq_mapped_truth', 'mappedidx_truth', 'neg_snp')
