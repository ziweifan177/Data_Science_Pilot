% Finds bases that are different between data sets
% masks bases that fall below the filtering threshold (mapping quality,
% coverage, and allelic fraction)
% requires: 1) *.mat file parsed from Pilon vcf with 'vcftomatrix_vcf_v7.py'
% Outputs *.mat file with:
% 1) 'filt' = matrix with only SNPs between datasets
    % filt formatted as 3D matrix: 
    % 1D = sample id  
    % 2D = (sample id, filtered base (0 if
    % masked), coverage, MQ, allelic fraction, Pilon quality info (look at
    % 'vcftomatrix_vcf_v7.py'), unfiltered base) x
    % 3D = position along the referenge genome
% 2) 'final_snp_pos' = SNP position along the referenge genome 
% 3) 'snp_filt_idx' = indicies to search through 'filt'

%load data
load('PA1.mat'); 

%filter parameters
filter = [4 5 6];

DPfilter = 6;
MQfilter = 45;
AFfilter = 210;
dataPA1 = data;

%Make mask (data row size), (data column size)
mask = ones(size(dataPA1,1),size(dataPA1,2));

%Mask out the filtered values
for iFilter = 1:length(filter)
mask(dataPA1(:,:,5)==filter(iFilter))=0;
end

% mask all 2 page data in data that is less than the DP and MQ and AF filter threshold
mask(dataPA1(:,:,2)<DPfilter)=0;
mask(dataPA1(:,:,3)<MQfilter)=0;
mask(dataPA1(:,:,4)<AFfilter & dataPA1(:,:,4)>1)=0;
mask((dataPA1(:,:,1)~=1) & (dataPA1(:,:,1)~=2) & (dataPA1(:,:,1)~=4) & (dataPA1(:,:,1)~=8))=0;

%change mask to uint8 for compatibility
mask = uint8(mask);
maskPA1 = double(mask);

% subtract the first value (sample1) of each position of page 1 (base) for all samples in that position
% mask bases that do not pass the filters (make them 0)
% sum each column
% find all position that the sum ~= 0 (discordant positions)
dataPA1 = double(dataPA1(:,:,1)).*double(maskPA1);
SNPindexPA1 = sum(bsxfun(@minus,double(dataPA1(:,:,1)),double(mode(dataPA1(:,:,1)))).*double(mask))~=0;%.*double(mask(1,:))~=0;

%% count unique samples, append replicate label to each [sample,position]
samples = [];
for iFile = 1:size(files,1)
[a b]=regexp(files(iFile,:),'[0-9]+[ABCDEFT]+_');
disp(str2num(files(iFile,a:(b-3))));
samples = [samples str2num(files(iFile,a:(b-3)))];
end
samplesPA1 = samples';

discordant_pos = [];
m2 = [];

% find all positions that have discordance (sum of map base by postion is not 0) - SNP index labeled them 0 (concodant) or 1 (discordant)
discordant_pos = find(SNPindexPA1~=0);
filt = [];

% loop for all discorant postions
for i = 1:length(discordant_pos);
% reset m2
m2 = [];
% apply mask to the ith discordant position and record it in filt(:,1,i) - position will become 0
filt(:,1,i) = dataPA1(:,discordant_pos(i),1).*maskPA1(:,discordant_pos(i));

filt(:,2,i) = filt(:,1,i);
filt(:,1,i) = samplesPA1;
filt(:,3:6,i) = data(:,discordant_pos(i),2:5);
filt(:,7,i) = data(:,discordant_pos(i),1);
filt(:,8,i) = [1:length(samplesPA1)];
end

snpmat = squeeze(filt(:,2,:)); % take only the snp positions and the base values
% loop through all noise filtered discordant snps
for k=1:length(discordant_pos);
snpidx = find(snpmat(:,k)); %find all non zero bases and index them
final_snp_posi(k)=sum(bsxfun(@minus,snpmat(snpidx,k),snpmat(snpidx(1),k))); %subtract one of the nonzero bases from all nonzerobases, then sum
% the above calls discordant sites only if there are nonzero calls that are
% different 
end
snp_filt_idx=(find(final_snp_posi)); %index of filt to find snps - filt(:,:,snp_filt_idx(1))
final_snp_pos = discordant_pos(find(final_snp_posi)); %final positions of snps

save('PA1_SNPindex75_MQ45.mat','snp_filt_idx','final_snp_pos','SNPindexPA1','maskPA1','samplesPA1', 'filt', 'discordant_pos','dataPA1','-v7.3');

