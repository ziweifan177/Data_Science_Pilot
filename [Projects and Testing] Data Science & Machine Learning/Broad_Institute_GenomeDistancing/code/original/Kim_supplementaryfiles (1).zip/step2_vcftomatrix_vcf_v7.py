from glob import glob
import pandas as pd
import numpy as np
import re
import time
t = time.clock()

# parses the base (A=1, C=2, G=4, T=8), coverage, mapping quality, allelic fraction, and Pilon quality information from Pilon vcf file into a matrix for Matlab (*.mat file)
# the output *.mat file is in the following format: (fileID) X (base position) X (info), where info is:
# 1) base (A=1, C=2, G=4, T=8), 2) coverage, 3) mapping quality, 4) allelic fraction, 5) and Pilon quality information
# 5) quality information defined in Pilon manual:
# 0=Pass, 1=LowCov, 2=Amb, 3=Amb;LowCov, 4=Del, 5=Del;Amb, and 6=Del;LowCov

# define filepath of *_snp.vcf (output of indel_remover.py) 
filepath = '/broad/hptmp/sk/aligned_CIPA_21_shorter_filter_ref/pilon/removed_indels/'

# load files matching this pattern
files = glob(filepath + '*_snp.vcf')
files.sort()

# analyze this many lines, not implemented yet
n_files = 24
files = files[:n_files]
n_lines = 6878000
n_cols = 5 # must match output of get_entries
# get the DP and MQ scores, have to do regex.match(input) to use
regex = re.compile('.*DP=(-*[0-9]*);.*MQ=(-*[0-9]*);.*QP=(-*[0-9]*,-*[0-9]*,-*[0-9]*,-*[0-9]*);.*AF=([0-9.]*).*')

# returns True if input passes filter
def get_entries(line):
    DP = 0
    MQ = 0
    QP2 = 0
    QP = 0
    AF = 0
    filt = 0
    call = line[0]
    if call == 'PASS':
    	filt = 0
    elif call == 'LowCov':
    	filt = 1
    elif call == 'Amb':
    	filt = 2
    elif call == 'Amb;LowCov':
    	filt = 3
    elif call == 'Del':
    	filt = 4
    elif call == 'Del;Amb':
    	filt = 5
    elif call == 'Del;LowCov':
    	filt = 6
    info_string = line[1]
    DP, MQ, QP2, AF = regex.match(info_string).groups()

    # converts QP to binary: [1,0,0,0] = 1, [0,1,0,0] =2, etc
    QP = sum([2**k if h == max(map(int, QP2.split(','))) else 0  for k,h in enumerate(map(int, QP2.split(',')))])
    # change n_cols to match number of items returned
    return QP, int(DP), int(MQ), int(round(255 * float(AF))), filt

for i, file in enumerate(files):
    # load the file using pandas, only retrieve 
    dataframe = pd.read_csv(file, "\t", engine='c', dtype=str, nrows=n_lines, header=None, usecols=[6, 7]) #, skiprows=5000000)
    arr = np.array(dataframe)
    print "loaded %d lines from %s in %.3f sec" % (arr.shape[0], file, time.clock()-t)
    t = time.clock()
    
    # the first time around, initialize the master array
    if i is 0:
        master_arr = np.zeros((n_files, arr.shape[0], n_cols), dtype=np.uint16)
    t = time.clock()
    # list comprehension to make matrix for this file: [[get_entries(line) for line in arr]]
    master_arr[i,:,:] = np.array([[get_entries(line) for line in arr]],dtype=np.uint16)
    print "converted array in %.3f sec" % (time.clock() - t)
    t = time.clock()


import datetime
fn = 'vcftomatrixout' % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
np.save(fn, master_arr)
print "saved matrix to %s in %.3f sec" % (fn+".npy", time.clock() - t)

import scipy.io
scipy.io.savemat(fn,{'files': files, 'data': master_arr})
