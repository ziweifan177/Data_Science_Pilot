% Generates an ROC plot as a function of allelic fractions (AF)
% requires: 
% 1) *.mat file with samples to compare that are parsed from Pilon vcf with 'vcftomatrix_vcf_v7.py'
% 2) output from 'step1_truebase_SNP_finder.m' run with gold standard: 
%   a) positive snp vs the reference genome from gold standard
%   b) negative snps = bases that are the same to the reference genome from gold standard
%   c) truebase = sequences of gold standard

% Load DATA

%filter parameters
filter = [4 5 6];

dataPA2 = uint16(data_4only);
clear data_4only;

for n = 1:26 % varies AF (out of 255) by 10 for 26 cycles
    %Make mask (data row size), (data column size)
    mask = ones(size(dataPA2,1),size(dataPA2,2));
    
    %Mask out the filtered values
    for iFilter = 1:length(filter);
    mask(dataPA2(:,:,5)==filter(iFilter))=0;
    end

    DPfilter = 6;
    MQfilter = 45;
    AFfilter = n*10;

    % mask dnsmpl_all 2 page data in data that is less than the DP and MQ and AF filter threshold
    mask(dataPA2(:,:,2)<DPfilter)=0;
    mask(dataPA2(:,:,3)<MQfilter)=0;
    mask(dataPA2(:,:,4)<AFfilter & dataPA2(:,:,4)>1)=0;

    %change mask to uint16 for compatibility
    mask = uint16(mask);
    maskPA2 = mask;

    % subtract the first value (sample1) of each position of page 1 (base) for dnsmpl_all samples in that position
    % mask bases that do not pass the filters (make them 0)
    % sum each column
    % find dnsmpl_all position that the sum ~= 0 (discordant positions)
    dataPA2(:,:,1) = dataPA2(:,:,1).*maskPA2;
    % tp = correctly identified SNPs (sample called snps when truth called
    % SNPs w/o NC
    tp_chip_merge(n) = length(find((dataPA2(4,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(4,pos_snp,1)~=0)));
    % incorrectly called non-SNPs - in snp positions in the truth, sample
    % called a non-SNP w NC (+ failed to identify SNPs)
    fn_chip_merge(n) = length(find(dataPA2(4,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    % incorrectly called SNPs - in non-snp positions in the truth, sample
    % called a SNP w/o NC
    fp_chip_merge(n) = length(find((dataPA2(4,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(4,neg_snp,1)~=0)));
    % correctly called non-snps - in non-snp positions in the truth, sample
    % called a non-SNP w/o NC
    tn_chip_merge(n) = length(find((dataPA2(4,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(4,neg_snp,1)~=0)));
    
    tp_chip_1only(n) = length(find((dataPA2(1,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(1,pos_snp,1)~=0)));
    fn_chip_1only(n) = length(find(dataPA2(1,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_chip_1only(n) = length(find((dataPA2(1,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(1,neg_snp,1)~=0)));
    tn_chip_1only(n) = length(find((dataPA2(1,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(1,neg_snp,1)~=0)));

    
    tp_chip_2only(n) = length(find((dataPA2(2,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(2,pos_snp,1)~=0)));
    fn_chip_2only(n) = length(find(dataPA2(2,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_chip_2only(n) = length(find((dataPA2(2,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(2,neg_snp,1)~=0)));
    tn_chip_2only(n) = length(find((dataPA2(2,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(2,neg_snp,1)~=0)));

    
    tp_chip_3only(n) = length(find((dataPA2(3,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(3,pos_snp,1)~=0)));
    fn_chip_3only(n) = length(find(dataPA2(3,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_chip_3only(n) = length(find((dataPA2(3,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(3,neg_snp,1)~=0)));
    tn_chip_3only(n) = length(find((dataPA2(3,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(3,neg_snp,1)~=0)));
    
    tp_chip_atrim(n) = length(find((dataPA2(13,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(13,pos_snp,1)~=0)));
    fn_chip_atrim(n) = length(find(dataPA2(13,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_chip_atrim(n) = length(find((dataPA2(13,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(13,neg_snp,1)~=0)));
    tn_chip_atrim(n) = length(find((dataPA2(13,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(13,neg_snp,1)~=0)));
    
    tp_tube_1only(n) = length(find((dataPA2(7,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(7,pos_snp,1)~=0)));
    fn_tube_1only(n) = length(find(dataPA2(7,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_tube_1only(n) = length(find((dataPA2(7,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(7,neg_snp,1)~=0)));
    tn_tube_1only(n) = length(find((dataPA2(7,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(7,neg_snp,1)~=0)));
    
    tp_tube_2only(n) = length(find((dataPA2(5,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(5,pos_snp,1)~=0)));
    fn_tube_2only(n) = length(find(dataPA2(5,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_tube_2only(n) = length(find((dataPA2(5,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(5,neg_snp,1)~=0)));
    tn_tube_2only(n) = length(find((dataPA2(5,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(5,neg_snp,1)~=0)));
    
    tp_tube_3only(n) = length(find((dataPA2(6,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(6,pos_snp,1)~=0)));
    fn_tube_3only(n) = length(find(dataPA2(6,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_tube_3only(n) = length(find((dataPA2(6,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(6,neg_snp,1)~=0)));
    tn_tube_3only(n) = length(find((dataPA2(6,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(6,neg_snp,1)~=0)));
    
    tp_tube_4only(n) = length(find((dataPA2(8,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(8,pos_snp,1)~=0)));
    fn_tube_4only(n) = length(find(dataPA2(8,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_tube_4only(n) = length(find((dataPA2(8,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(8,neg_snp,1)~=0)));
    tn_tube_4only(n) = length(find((dataPA2(8,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(8,neg_snp,1)~=0)));
    
    tp_tube_trim(n) = length(find((dataPA2(10,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(10,pos_snp,1)~=0)));
    fn_tube_trim(n) = length(find(dataPA2(10,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_tube_trim(n) = length(find((dataPA2(10,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(10,neg_snp,1)~=0)));
    tn_tube_trim(n) = length(find((dataPA2(10,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(10,neg_snp,1)~=0)));
    
    tp_tube_merge(n) = length(find((dataPA2(9,pos_snp,1)==truebase(pos_snp)) & (truebase(pos_snp)~=0) & (dataPA2(9,pos_snp,1)~=0)));
    fn_tube_merge(n) = length(find(dataPA2(9,pos_snp,1)~=truebase(pos_snp) & (truebase(pos_snp)~=0)));
    fp_tube_merge(n) = length(find((dataPA2(9,neg_snp,1)~=truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(9,neg_snp,1)~=0)));
    tn_tube_merge(n) = length(find((dataPA2(9,neg_snp,1)==truebase(neg_snp)) & (truebase(neg_snp)~=0) & (dataPA2(9,neg_snp,1)~=0)));
    

    
    % find dnsmpl_all positions that have discordance (sum of map base by postion is not 0) - SNP index labeled them 0 (concodant) or 1 (discordant)
    snpbyaf(n,1,1) = tp_chip_1only(n);
    snpbyaf(n,2,1) = tn_chip_1only(n);
    snpbyaf(n,3,1) = fp_chip_1only(n);
    snpbyaf(n,4,1) = fn_chip_1only(n);
    
    snpbyaf(n,1,2) = tp_chip_merge(n);
    snpbyaf(n,2,2) = tn_chip_merge(n);
    snpbyaf(n,3,2) = fp_chip_merge(n);
    snpbyaf(n,4,2) = fn_chip_merge(n);
    
    snpbyaf(n,1,4) = tp_tube_1only(n);
    snpbyaf(n,2,4) = tn_tube_1only(n);
    snpbyaf(n,3,4) = fp_tube_1only(n);
    snpbyaf(n,4,4) = fn_tube_1only(n);
    
    snpbyaf(n,1,5) = tp_tube_trim(n);
    snpbyaf(n,2,5) = tn_tube_trim(n);
    snpbyaf(n,3,5) = fp_tube_trim(n);
    snpbyaf(n,4,5) = fn_tube_trim(n);
    
    snpbyaf(n,1,6) = tp_tube_merge(n);
    snpbyaf(n,2,6) = tn_tube_merge(n);
    snpbyaf(n,3,6) = fp_tube_merge(n);
    snpbyaf(n,4,6) = fn_tube_merge(n);
    
    snpbyaf(n,1,8) = tp_chip_2only(n);
    snpbyaf(n,2,8) = tn_chip_2only(n);
    snpbyaf(n,3,8) = fp_chip_2only(n);
    snpbyaf(n,4,8) = fn_chip_2only(n);
    
    snpbyaf(n,1,9) = tp_chip_3only(n);
    snpbyaf(n,2,9) = tn_chip_3only(n);
    snpbyaf(n,3,9) = fp_chip_3only(n);
    snpbyaf(n,4,9) = fn_chip_3only(n);
    
    snpbyaf(n,1,10) = tp_tube_2only(n);
    snpbyaf(n,2,10) = tn_tube_2only(n);
    snpbyaf(n,3,10) = fp_tube_2only(n);
    snpbyaf(n,4,10) = fn_tube_2only(n);
    
    snpbyaf(n,1,11) = tp_tube_3only(n);
    snpbyaf(n,2,11) = tn_tube_3only(n);
    snpbyaf(n,3,11) = fp_tube_3only(n);
    snpbyaf(n,4,11) = fn_tube_3only(n);
    
    snpbyaf(n,1,12) = tp_tube_4only(n);
    snpbyaf(n,2,12) = tn_tube_4only(n);
    snpbyaf(n,3,12) = fp_tube_4only(n);
    snpbyaf(n,4,12) = fn_tube_4only(n);
    
    snpbyaf(n,1,13) = tp_chip_atrim(n);
    snpbyaf(n,2,13) = tn_chip_atrim(n);
    snpbyaf(n,3,13) = fp_chip_atrim(n);
    snpbyaf(n,4,13) = fn_chip_atrim(n);
 
end

spec_chip_1only = snpbyaf(:,2,1)./(snpbyaf(:,2,1)+snpbyaf(:,3,1));
sens_chip_1only = snpbyaf(:,1,1)./(snpbyaf(:,1,1)+snpbyaf(:,4,1));

spec_chip_2only = snpbyaf(:,2,8)./(snpbyaf(:,2,8)+snpbyaf(:,3,8));
sens_chip_2only = snpbyaf(:,1,8)./(snpbyaf(:,1,8)+snpbyaf(:,4,8));

spec_chip_3only = snpbyaf(:,2,9)./(snpbyaf(:,2,9)+snpbyaf(:,3,9));
sens_chip_3only = snpbyaf(:,1,9)./(snpbyaf(:,1,9)+snpbyaf(:,4,9));

spec_chip_merge = snpbyaf(:,2,2)./(snpbyaf(:,2,2)+snpbyaf(:,3,2));
sens_chip_merge = snpbyaf(:,1,2)./(snpbyaf(:,1,2)+snpbyaf(:,4,2));

sens_tube_1only = snpbyaf(:,1,4)./(snpbyaf(:,1,4)+snpbyaf(:,4,4));
spec_tube_1only = snpbyaf(:,2,4)./(snpbyaf(:,2,4)+snpbyaf(:,3,4));

sens_tube_2only = snpbyaf(:,1,10)./(snpbyaf(:,1,10)+snpbyaf(:,4,10));
spec_tube_2only = snpbyaf(:,2,10)./(snpbyaf(:,2,10)+snpbyaf(:,3,10));

sens_tube_3only = snpbyaf(:,1,11)./(snpbyaf(:,1,11)+snpbyaf(:,4,11));
spec_tube_3only = snpbyaf(:,2,11)./(snpbyaf(:,2,11)+snpbyaf(:,3,11));

sens_tube_4only = snpbyaf(:,1,12)./(snpbyaf(:,1,12)+snpbyaf(:,4,12));
spec_tube_4only = snpbyaf(:,2,12)./(snpbyaf(:,2,12)+snpbyaf(:,3,12));

sens_tube_trim = snpbyaf(:,1,5)./(snpbyaf(:,1,5)+snpbyaf(:,4,5));
spec_tube_trim = snpbyaf(:,2,5)./(snpbyaf(:,2,5)+snpbyaf(:,3,5));

sens_tube_merge = snpbyaf(:,1,6)./(snpbyaf(:,1,6)+snpbyaf(:,4,6));
spec_tube_merge = snpbyaf(:,2,6)./(snpbyaf(:,2,6)+snpbyaf(:,3,6));

sens_chip_atrim = snpbyaf(:,1,13)./(snpbyaf(:,1,13)+snpbyaf(:,4,13));
spec_chip_atrim = snpbyaf(:,2,13)./(snpbyaf(:,2,13)+snpbyaf(:,3,13));


% plots ROC, 1-spec vs sens
plot((1-spec_chip_merge),sens_chip_merge,'k')
hold on
plot((1-spec_tube_trim),sens_tube_trim,'r')
plot((1-spec_chip_1only),sens_chip_1only,'g')
plot((1-spec_chip_2only),sens_chip_2only,'b')
plot((1-spec_chip_3only),sens_chip_3only,'c')
plot((1-spec_tube_1only),sens_tube_1only,'m')
plot((1-spec_tube_4only),sens_tube_4only,'y')
scatter((1-spec_chip_merge(21)),sens_chip_merge(21),250,'k')
scatter((1-spec_tube_trim(21)),sens_tube_trim(21),250,'r')
scatter((1-spec_chip_1only(21)),sens_chip_1only(21),250,'g')
scatter((1-spec_chip_2only(21)),sens_chip_2only(21),250,'b')
scatter((1-spec_chip_3only(21)),sens_chip_3only(21),250,'c')
scatter((1-spec_tube_1only(21)),sens_tube_1only(21),250,'m')
scatter((1-spec_tube_4only(21)),sens_tube_4only(21),250,'k')


%save('ROCtriplicate6.mat','snpbyaf','-v7.3');
% figure(8); plot(bsxfun(@rdivide,(snpbyaf(:,2:end,1)),snpbyaf(1,2:end,1)),bsxfun(@rdivide,(snpbyaf(:,2:end,2)),snpbyaf(1,2:end,2)))
% hold on;snp
% c = linspace(1,10,length(snpbyaf));
% % scatter plot for the 21th (AF=210) data on the plot
% scatter(bsxfun(@rdivide,(snpbydp(21,2:end,1)),snpbydp(1,2:end,1)),bsxfun(@rdivide,(snpbydp(21,2:end,2)),snpbydp(1,2:end,2)),500,'r')