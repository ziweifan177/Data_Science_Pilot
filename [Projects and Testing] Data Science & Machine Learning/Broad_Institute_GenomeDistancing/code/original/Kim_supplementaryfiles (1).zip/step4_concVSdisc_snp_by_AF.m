% This program generates a convergent vs divergent base fraction from a
% triplcate replicate Pilon data (*.mat file) as a function of allelic
% fraction (AF)
% requires: 
% 1) triplicate repilcate *.mat file parsed from Pilon vcf with 'vcftomatrix_vcf_v7.py'
% 2) reference genome fasta file converted to *.mat file (A=1, C=2, G=4, T=8)
% 3) output matfile from 'truebasefinder.m' ('truebase.mat')
% outputs a 

clear all
load('58_AT_only.mat'); % 1) triplicate repilcate *.mat file parsed from Pilon vcf with 'vcftomatrix_vcf_v7.py'
load('PAv14_ref_seq.mat'); % 2) reference genome fasta file converted to *.mat
load('truebasePA3.mat'); % 3) output matfile from 'truebasefinder.m' ('truebase.mat')

%filter parameters
filter = [4 5 6];

dataPAC = data(1:3,:,:);
clear data;

%Make mask (data row size), (data column size)
mask = ones(size(dataPAC,1),size(dataPAC,2));

%Mask out the filtered values
for iFilter = 1:length(filter);
mask(dataPAC(:,:,5)==filter(iFilter))=0;
end

for n = 1:26

DPfilter = 6;
MQfilter = 45;
AFfilter = n*10

% mask all 2 page data in data that is less than the DP and MQ and AF filter threshold
mask(dataPAC(:,:,2)<DPfilter)=0;
mask(dataPAC(:,:,3)<MQfilter)=0;
mask(dataPAC(:,:,4)<AFfilter & dataPAC(:,:,4)>1)=0;
mask((dataPAC(:,:,1)~=1) & (dataPAC(:,:,1)~=2) & (dataPAC(:,:,1)~=4) & (dataPAC(:,:,1)~=8))=0;

%change mask to uint16 for compatibility
mask = uint16(mask);
maskPAC = mask;

% subtract the mode of (sample1) of each position of page 1 (base) for all samples in that position
% mask bases that do not pass the filters (make them 0)
% sum each column
% find all position that the sum ~= 0 (discordant positions)
datamask = double(dataPAC(:,:,1)).*double(mask);

% mask all positions with more than one NC
datamask(:,find(sum(datamask(:,:)==0)>1))=0;

% positions where replicate calls after masking are not the same (discordant SNPs) 
% ** when there are more than two NC (0), that position is not used.
% only all non-zero rows are counted (.*double(mask(:,:)))
SNPindexPAC = sum(bsxfun(@minus,double(datamask(:,:)),double(mode(datamask(:,:)))).*double(mask(:,:)))~=0;

% NC are also counted as Discordant SNPs
%SNPindexPAC = sum(bsxfun(@minus,double(datamask(:,:)),double(mode(datamask(:,:)))))~=0;

% count unique samples, append replicate label to each [sample,position]
samples = [];
for iFile = 1:size(files,1);
[a b]=regexp(files(iFile,:),'[0-9]+[ABCDEF]_');
samples = [samples str2num(files(iFile,a:(b-2)))];
end
samplesPAC = samples';

discordant_pos = [];
m2 = [];
discordant_pos = find(SNPindexPAC(mappedidx_truth)~=0);
conc = [];

% discordant site indexes = all replicates equal & one of replicate is not
% equal reference seq & coverage is not equal 0
conc = (SNPindexPAC(mappedidx_truth) == 0) & (mode(datamask(:,mappedidx_truth,1)) ~= PAv14_ref_seq(mappedidx_truth)) & (sum(datamask(:,mappedidx_truth)==0)<1);

numconc = sum(conc);

% find all positions that have discordance (sum of map base by postion is not 0) - SNP index labeled them 0 (concodant) or 1 (discordant)
snpbyaf(n,1,1:2) = n;
snpbyaf(n,7,1) = size(discordant_pos,2);
snpbyaf(n,7,2) = numconc;

end

filt = [];

% loop for all discorant postions
for i = 1:length(discordant_pos);
% reset m2
m2 = [];
% apply mask to the ith discordant position and record it in filt(:,1,i) - position will become 0
filt(:,1,i) = dataPAC(:,discordant_pos(i),1).*maskPAC(:,discordant_pos(i));

filt(:,2,i) = filt(:,1,i);
filt(:,1,i) = samplesPAC;
filt(:,3:6,i) = dataPAC(:,discordant_pos(i),2:5);
end

snpbyaf_PA3 = snpbyaf;
save('cvd_PA3.mat','mappedidx_truth','snpbyaf_PA3')
figure(8); plot(bsxfun(@rdivide,(snpbyaf(:,2:end,1)),snpbyaf(1,2:end,1)),bsxfun(@rdivide,(snpbyaf(:,2:end,2)),snpbyaf(1,2:end,2)))
hold on;
scatter(bsxfun(@rdivide,(snpbyaf(21,7,1)),snpbyaf(1,7,1)),bsxfun(@rdivide,(snpbyaf(21,7,2)),snpbyaf(1,7,2)),500,'m')
